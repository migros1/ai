async function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    const message = userInput.value.trim();

    if (message === '') return;

    // Kullanıcı mesajını ekle
    appendMessage('user', message);
    userInput.value = '';

    try {
        // API isteği
        const response = await fetch(`https://remix.itz-ashlynn.workers.dev/?prompt=${encodeURIComponent(message)}`);
        const data = await response.json();

        // AI yanıtını ekle
        appendMessage('ai', data.message);
    } catch (error) {
        appendMessage('ai', 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.');
    }
}

function appendMessage(sender, message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Enter tuşu ile mesaj gönderme
document.getElementById('user-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
}); 